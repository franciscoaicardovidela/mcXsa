/*
    Plugin-SDK (Grand Theft Auto 3) header file
    Authors: GTA Community. See more here
    https://github.com/DK22Pac/plugin-sdk
    Do not delete this comment block. Respect others' work!
*/
#pragma once

#include "PluginBase.h"
#include "CVector.h"

class PLUGIN_API cAudioScriptObject {
    PLUGIN_NO_DEFAULT_CONSTRUCTION(cAudioScriptObject)

public:
    short m_nAudioId;
    CVector m_vecPosition;
    int m_nStatusIndex; //!< >=0 - sound index, <0 - error status

    SUPPORTED_10EN_11EN_STEAM void Reset();

    SUPPORTED_10EN_11EN_STEAM static void LoadAllAudioScriptObjects(unsigned char *buf, unsigned int size);
    SUPPORTED_10EN_11EN_STEAM static void SaveAllAudioScriptObjects(unsigned char *buf, unsigned int *size);
};
VALIDATE_OFFSET(cAudioScriptObject, m_nAudioId, 0x0);
VALIDATE_OFFSET(cAudioScriptObject, m_vecPosition, 0x4);
VALIDATE_OFFSET(cAudioScriptObject, m_nStatusIndex, 0x10);
VALIDATE_SIZE(cAudioScriptObject, 0x14);

SUPPORTED_10EN_11EN_STEAM void PlayOneShotScriptObject(unsigned char id, CVector const &pos);

VALIDATE_SIZE(cAudioScriptObject, 0x14);

#include "meta/meta.cAudioScriptObject.h"
